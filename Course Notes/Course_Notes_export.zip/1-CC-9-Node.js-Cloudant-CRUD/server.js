var express = require("express");
var app = express();
var cfenv = require("cfenv");
var bodyParser = require('body-parser')

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

var mydb;

/////////////// insert /////////////////
app.get("/insert", function (req, res) {
  if(!mydb) {
    console.log("No database.");
    response.send("No database.");
    return;
  }
  var person = {
	name: req.query.name,
  	email: req.query.email,
  	address: {
		Street: req.query.street,
		city: req.query.city,
		state: req.query.state
	}
  }
  mydb.insert(person, function(err, body, header) {
    if (err) {
      return console.log('[mydb.insert] ', err.message);
    }
    res.end(JSON.stringify(person));
  })
})

/////////////// getAll /////////////////
app.get("/getAll", function (req, res) {
	  var names = [];
	  if(!mydb) {
		res.json("No database.");
		return;
	  }
	  mydb.list({ include_docs: true }, function(err, body) {
		if (!err) {
			body.rows.forEach(function(row) {
			  if(row.doc.name)
				names.push({name : row.doc.name, email : row.doc.email});
			  });
			res.json(names);
		}
	  });
});

//////////////// getPerson ////////////////
app.get("/getPerson", function (req, res) {
  var names = [];
  if(!mydb) {
    console.log("No database.");
    response.send("No database.");
    return;
  }
  id = req.query.id;

  mydb.get(id, function(err, body) {
	if (!err) {
		console.log('Document contents:' + body.name);
		res.json({name : body.name});
	}
  })

})

//////////////// delete document ////////////////
app.get("/delete", function (req, res) {
	id = req.query.id
	rev = req.query.rev
	mydb.destroy(id, rev, function(err, body, header) {
	  if (!err) {
		console.log("Successfully deleted doc: ", id);
		res.send("Successfully deleted doc: "+ id);
	  }
	});
});

//////////////// get all indexes ////////////////
app.get("/getIndexes", function (req, res) {
	mydb.index(function(er, result) {
	  if (er) { throw er; }
      console.log('The database has %d indexes', result.indexes.length);
	  for (var i = 0; i < result.indexes.length; i++) {
	      console.log('  %s (%s): %j', result.indexes[i].name, result.indexes[i].type, result.indexes[i].def);
	      res.write(result.indexes[i].name + '\n')
  	  }
  	  res.send();
    });
});

app.get("/findByEmail", function (req, res) {
	mydb.find({selector:{email:'jsmith@gmail.com'}}, function(er, result) {
	  if (er) {
		throw er;
	  }
	  console.log('Found %d documents with email ', result.docs.length);
	  for (var i = 0; i < result.docs.length; i++) {
		console.log('  Doc id: %s', result.docs[i]._id);
		res.write(result.docs[i]._id + '\n')
		res.write(result.docs[i].name + '\n')
	  }
	  res.send();
	});
});

////////////////////////////////////////////////////////
// load local VCAP configuration  and service credentials
var vcapLocal;
try {
  vcapLocal = require('./vcap-local.json');
  console.log("Loaded local VCAP", vcapLocal);
} catch (e) { }

const appEnvOpts = vcapLocal ? { vcap: vcapLocal} : {}

const appEnv = cfenv.getAppEnv(appEnvOpts);

if (appEnv.services['cloudantNoSQLDB'] || appEnv.getService(/cloudant/)) {
	 // Load the Cloudant library.
	 var Cloudant = require('cloudant');

	 // Initialize database with credentials
	 if (appEnv.services['cloudantNoSQLDB']) {
		 // CF service named 'cloudantNoSQLDB'
		 var cloudant = Cloudant(appEnv.services['cloudantNoSQLDB'][0].credentials);
	 } else {
		 // user-provided service with 'cloudant' in its name
		 //var cloudant = Cloudant(appEnv.getService(/cloudant/).credentials);
	 }

	 //database name
	 var dbName = 'sales';

	 // Create a new database.
	 cloudant.db.create(dbName, function(err, data) {
		if(!err) //err if database doesn't already exists
		  console.log("Created database: " + dbName);
	 });
	 mydb = cloudant.db.use(dbName);
} else {
	 console.log("Local Host access to Cloudant");
	 require('dotenv').config();
	 var Cloudant = require('cloudant');
	 var account = process.env.account;
	 var mypassword = process.env.password;
	 var host = process.env.host;
	 //var url = 'https://' + account + ':' + password + '@' + host;
	 Cloudant({url:host, username:account, password:mypassword}, function(err, cloudant){
		if (err) {
		 return console.log('Failed to initialize Cloudant: ' + err.message);
		}
		mydb = cloudant.db.use("sales");

		var name_index = {name:'name-index', type:'json', index:{fields:['name']}}
		mydb.index(name_index, function(er, response) {
		  if (er) {throw er;}
		  console.log('Index creation result: %s', response.result);
		});

		var email_index = {name:'email-index', type:'json', index:{fields:['email']}}
		mydb.index(email_index, function(er, response) {
		  if (er) {throw er;}
		  console.log('Index creation result: %s', response.result);
		});
	 })

}


app.use(express.static(__dirname + '/public'));

var port = process.env.PORT || 3000
app.listen(port, function() {
    console.log("Server running on http://localhost:" + port);
});
