var express = require("express");
var app = express();
var cfenv = require("cfenv");
var bodyParser = require('body-parser')

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use(express.static(__dirname + '/public'));

var mydb;

/////////////// insert /////////////////
app.get("/insert", function (req, res) {
  if(!mydb) {
    console.log("No database.");
    response.send("No database.");
    return;
  }
  var person = {
	title: req.query.title,
  	author: req.query.author,
  	genre: req.query.genre,
  	year: req.query.year
  }
  mydb.insert(person, function(err, body, header) {
    if (err) {
      return console.log('[mydb.insert] ', err.message);
    }
    res.end(JSON.stringify(person));
  })
})

/////////////// getAll /////////////////
app.get("/getAll", function (req, res) {
	  var names = [];
	  if(!mydb) {
		res.json("No database.");
		return;
	  }
	  mydb.list({ include_docs: true }, function(err, body) {
		if (!err) {
			body.rows.forEach(function(row) {
			  if(row.doc.title)
				names.push({Title : row.doc.title, Author : row.doc.author, Genre : row.doc.genre, Year : row.doc.year});
			  });
			res.json(names);
		}
	  });
});




//////////////// delete document ////////////////
app.get("/delete", function (req, res) {
	mydb.find({selector:{title:req.query.title}}, function(er, result) {
		  if (er) {
			throw er;
		  }
		  console.log('Found %d documents with email ', result.docs.length);
       if (result.docs.length > 0){
		  id = result.docs[0]._id
	      rev = result.docs[0]._rev

	      mydb.destroy(id, rev, function(err, body, header) {
		  	  if (!err) {
		  		console.log("Successfully deleted doc: ", id);
		  		res.send("Successfully deleted doc: "+ id);
		  	  }
		 });
	 } else{
		 res.send("Not Found");
	 }
	});
});

//////////////// modify document ////////////////
app.get("/modify", function (req, res) {
	mydb.find({selector:{title:req.query.title}}, function(er, result) {
		  if (er) {
			throw er;
		  }
		  console.log('Found %d documents with email ', result.docs.length);
       if (result.docs.length > 0){
		  id = result.docs[0]._id
	      rev = result.docs[0]._rev

	      var person = {
			    _id: id,
			    _rev : rev,
		  	    title: req.query.title,
		    	author: req.query.author,
		    	genre: req.query.genre,
		    	year: req.query.year
		    }
		    mydb.insert(person, function(err, body, header) {
		      if (err) {
		        return console.log('[mydb.insert] ', err.message);
		      }
		      res.end(JSON.stringify(person));
     })
	 } else{
		 res.send("Not Found");
	 }
	});
});


//////////////// getPersonByAuthor ////////////////
app.get("/getPersonByAuthor", function (req, res) {
	mydb.find({selector:{author:req.query.author}}, function(er, result) {
		  if (er) {
			throw er;
		  }
		  console.log('Found %d documents with email ', result.docs.length);
		  if (result.docs.length > 0){

           var names = [];
		    for (var i = 0; i < result.docs.length; i++) {
		      names.push({Title : result.docs[i].title, Author : result.docs[i].author, Genre : result.docs[i].genre, Year : result.docs[i].year});
	        }
		  	res.json(names);
		  } else{
		  	res.send("Not Found");
	     }
	});
});

//////////////// getPersonByTitle ////////////////
app.get("/getPersonByTitle", function (req, res) {
	mydb.find({selector:{title:req.query.title}}, function(er, result) {
		  if (er) {
			throw er;
		  }
		  console.log('Found %d documents with email ', result.docs.length);
		  if (result.docs.length > 0){

           var names = [];
		    for (var i = 0; i < result.docs.length; i++) {
		      names.push({Title : result.docs[i].title, Author : result.docs[i].author, Genre : result.docs[i].genre, Year : result.docs[i].year});
	        }
		  	res.json(names);
		  } else{
		  	res.send("Not Found");
	     }
	});
});

//////////////// getPersonByGenre ////////////////
app.get("/getPersonByGenre", function (req, res) {
	mydb.find({selector:{genre:req.query.genre}}, function(er, result) {
		  if (er) {
			throw er;
		  }
		  console.log('Found %d documents with email ', result.docs.length);
		  if (result.docs.length > 0){

           var names = [];
		    for (var i = 0; i < result.docs.length; i++) {
		      names.push({Title : result.docs[i].title, Author : result.docs[i].author, Genre : result.docs[i].genre, Year : result.docs[i].year});
	        }
		  	res.json(names);
		  } else{
		  	res.send("Not Found");
	     }
	});
});

//////////////// getPersonByYear ////////////////
app.get("/getPersonByYear", function (req, res) {
	mydb.find({selector:{year:req.query.year}}, function(er, result) {
		  if (er) {
			throw er;
		  }
		  console.log('Found %d documents with email ', result.docs.length);
		  if (result.docs.length > 0){

           var names = [];
		    for (var i = 0; i < result.docs.length; i++) {
		      names.push({Title : result.docs[i].title, Author : result.docs[i].author, Genre : result.docs[i].genre, Year : result.docs[i].year});
	        }
		  	res.json(names);
		  } else{
		  	res.send("Not Found");
	     }
	});
});


////////////////////////////////////////////////////////
// load local VCAP configuration  and service credentials
var vcapLocal;
try {
  vcapLocal = require('./vcap-local.json');
  console.log("Loaded local VCAP", vcapLocal);
} catch (e) { }

const appEnvOpts = vcapLocal ? { vcap: vcapLocal} : {}

const appEnv = cfenv.getAppEnv(appEnvOpts);

if (appEnv.services['cloudantNoSQLDB'] || appEnv.getService(/cloudant/)) {
	 // Load the Cloudant library.
	 var Cloudant = require('cloudant');

	 // Initialize database with credentials
	 if (appEnv.services['cloudantNoSQLDB']) {
		 // CF service named 'cloudantNoSQLDB'
		 var cloudant = Cloudant(appEnv.services['cloudantNoSQLDB'][0].credentials);
	 } else {
		 // user-provided service with 'cloudant' in its name
		 //var cloudant = Cloudant(appEnv.getService(/cloudant/).credentials);
	 }

	 //database name
	 var dbName = 'books';

	 // Create a new database.
	 cloudant.db.create(dbName, function(err, data) {
		if(!err) //err if database doesn't already exists
		  console.log("Created database: " + dbName);
	 });
	 mydb = cloudant.db.use(dbName);
} else {
	 console.log("Local Host access to Cloudant");
	 require('dotenv').config();
	 var Cloudant = require('cloudant');
	 var account = process.env.account;
	 var mypassword = process.env.password;
	 var host = process.env.host;
	 //var url = 'https://' + account + ':' + password + '@' + host;
	 Cloudant({url:host, username:account, password:mypassword}, function(err, cloudant){
		if (err) {
		 return console.log('Failed to initialize Cloudant: ' + err.message);
		}
		mydb = cloudant.db.use("books");

		var name_index = {name:'name-index', type:'json', index:{fields:['name']}}
		mydb.index(name_index, function(er, response) {
		  if (er) {throw er;}
		  console.log('Index creation result: %s', response.result);
		});

		var email_index = {name:'email-index', type:'json', index:{fields:['email']}}
		mydb.index(email_index, function(er, response) {
		  if (er) {throw er;}
		  console.log('Index creation result: %s', response.result);
		});
	 })

}


app.use(express.static(__dirname + '/public'));

var port = process.env.PORT || 3000
app.listen(port, function() {
    console.log("Server running on http://localhost:" + port);
});
